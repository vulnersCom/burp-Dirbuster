# -*- coding: utf-8 -*-
__author__ = 'videns'

import code
import re
import array
from java.io import PrintWriter
from burp import IBurpExtender, \
    IScannerInsertionPointProvider, \
    IScannerInsertionPoint, \
    IParameter, \
    IScannerCheck, \
    IScanIssue, \
    IHttpService, \
    IHttpListener


errors = [r'\.php on line [0-9]+',
        r'Fatal error:',
        r'\.php:[0-9]+',
        r'\[(ODBC SQL Server Driver|SQL Server)\]',
        r'You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near',
        r'\.java:[0-9]+',
        r'\.java\((Inlined )?Compiled Code\)',
        r'[A-Za-z\.]+\(([A-Za-z0-9, ]+)?\) \+[0-9]+',
        r'at (\/[A-Za-z0-9\\.]+)*\.pm line [0-9]+']

error_regexp = [re.compile(x, re.IGNORECASE) for x in errors]


class BurpExtender(IBurpExtender, IHttpListener):
    def registerExtenderCallbacks(self, callbacks):
        global burp_callbacks
        burp_callbacks = callbacks
        global burp_helpers
        burp_helpers = burp_callbacks.getHelpers()
        # set our extension name
        callbacks.setExtensionName("ZN Burp Extension 0.4")

        # obtain our output and error streams
        global stdout
        stdout = PrintWriter(callbacks.getStdout(), True)
        global stderr
        stderr = PrintWriter(callbacks.getStderr(), True)

        # write a message to our output stream
        println("Plugin version 0.4")


        callbacks.registerHttpListener(self)

        self.foundStackTrace = set()


    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        if messageIsRequest == 0:
            url = burp_helpers.analyzeRequest(messageInfo).getUrl()
            if url in self.foundStackTrace:
                return
            if burp_callbacks.isInScope(url):
                response = burp_helpers.analyzeResponse(messageInfo.getResponse())
                if response.getStatusCode() == 404:
                    return
                raw_response = burp_helpers.bytesToString(messageInfo.getResponse())
                for one_error_regexp in error_regexp:
                    match = one_error_regexp.search(raw_response)
                    if match:
                        self.foundStackTrace.add(url)
                        match_res = match.group(0)
                        start_pos = raw_response.find(match_res)
                        markers= [array.array('i', [start_pos, start_pos + len(match_res)])]
                        new_messages = burp_callbacks.applyMarkers(messageInfo, None, markers)
                        burp_callbacks.addScanIssue(CustomScanIssue(messageInfo.getHttpService(),
                                                               url,
                                                               [new_messages],
                                                               "Detailed error",
                                                               "Detailed error found, <b>%s</b>" % match_res,
                                                               "Firm",
                                                               "High"))
                        return
        return


class CustomScanIssue(IScanIssue):
    def __init__(self, httpService, url, httpMessages, name, detail, confidence, severity):
        self._http_service = httpService
        self._url = url
        self._http_messages = httpMessages
        self._name = name
        self._detail = detail
        self._severity = severity
        self._confidence = confidence
        return

    def getUrl(self):
        return self._url

    def getIssueName(self):
        return self._name

    def getIssueType(self):
        return 134217728

    def getSeverity(self):
        return self._severity

    def getConfidence(self):
        return self._confidence

    def getIssueBackground(self):
        return None

    def getRemediationBackground(self):
        return None

    def getIssueDetail(self):
        return self._detail

    def getRemediationDetail(self):
        return None

    def getHttpMessages(self):
        return self._http_messages

    def getHttpService(self):
        return self._http_service

def println(message):
    stdout.println(message)