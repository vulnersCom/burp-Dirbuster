# -*- coding: utf-8 -*-
from burp import IBurpExtender
from burp import IScannerInsertionPointProvider
from burp import IScannerInsertionPoint
from java.io import PrintWriter
from java.lang import RuntimeException
from string import Template
import re
import array

class BurpExtender(IBurpExtender, IScannerInsertionPointProvider):
    
    #
    # implement IBurpExtender
    #
    
    def	registerExtenderCallbacks(self, callbacks):

        global burp_callbacks
        burp_callbacks = callbacks
        global burp_helpers
        burp_helpers = burp_callbacks.getHelpers()
        # set our extension name
        burp_callbacks.setExtensionName("ZN Extension 0.5")
        
        # obtain our output and error streams
        global stdout
        stdout = PrintWriter(callbacks.getStdout(), True)
        global stderr
        stderr = PrintWriter(callbacks.getStderr(), True)

        # write a message to our output stream
        println("Plugin version 0.5")
        
        # write a message to our error stream

        # write a message to the Burp alerts tab
        burp_callbacks.registerScannerInsertionPointProvider(self)
        
        # throw an exception that will appear in our error stream

    def getInsertionPoints(self, baseRequestResponse):
        return [CustomInsertionPoint(baseRequestResponse)]


class CustomInsertionPoint(IScannerInsertionPoint):
    def __init__(self, baseRequestResponse):

        headerName = "Secret-Header"

        request = burp_helpers.bytesToString(baseRequestResponse.getRequest())

        request = re.sub('(?im)^(Host: [a-zA-Z0-9-_.:]*)\r\n', '\\1\r\n%s: ${attackPayload}\r\n' % headerName, request, 1)




        self._requestTemplate = Template(request)

        return

    def getInsertionPointName(self):
        return "Secret-Header"

    def getBaseValue(self):
        return ""

    def buildRequest(self, payload):
        payload = burp_helpers.bytesToString(payload)
        payload = burp_helpers.urlEncode(payload)

        payloads = {"attackPayload":payload}

        request = self._requestTemplate.safe_substitute(payloads)
        self._final_request = request
        return burp_helpers.stringToBytes(request)


    def getPayloadOffsets(self, payload):
        if not isinstance(payload, str):
            payload = self._helpers.bytesToString(payload)
        offset_start = self._final_request.find(payload)
        if offset_start != -1:
            return array.array('i',[offset_start, offset_start+len(payload)])
        return None

    def getInsertionPointType(self):
        return 65


def println(message):
    stdout.println(message)