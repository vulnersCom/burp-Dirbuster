# -*- coding: utf-8 -*-
from burp import IBurpExtender, IScanIssue, IScannerCheck
from java.io import PrintWriter
from java.lang import RuntimeException
from uuid import uuid4
import urllib2
import array

class BurpExtender(IBurpExtender, IScannerCheck):
    
    #
    # implement IBurpExtender
    #
    
    def	registerExtenderCallbacks(self, callbacks):

        global burp_callbacks
        burp_callbacks = callbacks
        global burp_helpers
        burp_helpers = burp_callbacks.getHelpers()
        # set our extension name
        burp_callbacks.setExtensionName("ZN Extension 0.2")
        
        # obtain our output and error streams
        self.stdout = PrintWriter(burp_callbacks.getStdout(), True)
        self.stderr = PrintWriter(burp_callbacks.getStderr(), True)
        
        # write a message to our output stream
        self.println("Hello output")
        self.println("Plugin version 0.2")
        
        # write a message to our error stream
        #self.stderr.println("Hello errors")
        
        # write a message to the Burp alerts tab
        #burp_callbacks.issueAlert("Hello alerts")
        burp_callbacks.registerScannerCheck(self)
        
        # throw an exception that will appear in our error stream
        #raise RuntimeException("Hello exception")


    def doActiveScan1(self,baseRequestResponse, insertionPoint):
        for i in range(10):
            payload = "31337"+str(uuid4()).replace("-","")[:8]
            request = "GET /%s HTTP/1.0\r\nHost: ya.ru\r\n\r\n" % payload
            attack = burp_callbacks.makeHttpRequest("ya.ru",
                                                    80,
                                                    False,
                                                    burp_helpers.stringToBytes(request))
            response = burp_helpers.analyzeResponse(attack)
            self.println(response.getStatusCode())


    def doActiveScan3(self,baseRequestResponse, insertionPoint):
        for i in range(10):
            url = "31337"+str(uuid4()).replace("-","")[:8]
            try:
                response = urllib2.urlopen("http://qiwi.com/"+url)
                page_date = response.read()
            except urllib2.HTTPError, e:
                if e.code == 404:
                    print("Error 404")

    def doActiveScan(self,baseRequestResponse, insertionPoint):
        name = insertionPoint.getInsertionPointName()
        value = insertionPoint.getBaseValue()
        if name == "cc":
            payload = "ATTACK_HERE"
            payload_bytes = burp_helpers.stringToBytes(payload)
            attack = burp_callbacks.makeHttpRequest(baseRequestResponse.getHttpService(),
                                                 insertionPoint.buildRequest(payload_bytes))
            response = attack.getResponse()
            request_markers = [insertionPoint.getPayloadOffsets(payload)]
            attack = burp_callbacks.applyMarkers(attack, request_markers, None)
            return [CustomScanIssue(burp_helpers.analyzeRequest(attack).getUrl(),
                               "Test vulnerability",
                               134217728,
                               "High",
                               "Certain",
                               None,
                               None,
                               "Some details about vulnerability",
                               None,
                               [attack],
                               attack.getHttpService())]


    #create function for active scan
    def doActiveScan2(self, baseRequestResponse, insertionPoint):
        #return
        name = insertionPoint.getInsertionPointName()
        value = insertionPoint.getBaseValue()
        self.println("Attacking point %s" % name)
        #for i in range(10):
        payload = str(uuid4()).replace("-","")[:8]
        payload_bytes = burp_helpers.stringToBytes(payload)
        attack = burp_callbacks.makeHttpRequest(baseRequestResponse.getHttpService(),
                                                 insertionPoint.buildRequest(payload_bytes))
        response = attack.getResponse()
        response_str = burp_helpers.bytesToString(response)
        if payload in response_str:
            self.println("Payload was found %s" % payload)
            #request_markers = [insertionPoint.getPayloadOffsets(payload)]
            #response_markers = [array.array('i', [response_str.find(payload), response_str.find(payload)+len(payload)])]
            #attack = burp_callbacks.applyMarkers(attack, request_markers, response_markers)
            return [CustomScanIssue(burp_helpers.analyzeRequest(attack).getUrl(),
                               "Test vulnerability",
                               134217728,
                               "High",
                               "Certain",
                               None,
                               None,
                               "Some details about vulnerability",
                               None,
                               [attack],
                               attack.getHttpService())]



    def doPassiveScan(self, baseRequestResponse):
        pass

    def println(self, message):
        self.stdout.println(message)


class CustomScanIssue(IScanIssue):
    def __init__(self, Url, IssueName, IssueType, Severity, Confidence, IssueBackground,
                 RemediationBackground, IssueDetail, RemediationDetail, HttpMessages, HttpService):
        self._Url = Url
        self._IssueName = IssueName
        self._IssueType = IssueType
        self._Severity = Severity
        self._Confidence = Confidence
        self._IssueBackground = IssueBackground
        self._RemediationBackground = RemediationBackground
        self._IssueDetail = IssueDetail
        self._RemediationDetail = RemediationDetail
        self._HttpMessages = HttpMessages
        self._HttpService = HttpService

    def getUrl(self):
        return self._Url

    def getIssueName(self):
        return self._IssueName

    def getIssueType(self):
        return self._IssueType

    def getSeverity(self):
        return self._Severity

    def getConfidence(self):
        return self._Confidence

    def getIssueBackground(self):
        return self._IssueBackground

    def getRemediationBackground(self):
        return self._RemediationBackground

    def getIssueDetail(self):
        return self._IssueDetail

    def getRemediationDetail(self):
        return self._RemediationDetail

    def getHttpMessages(self):
        return self._HttpMessages

    def getHttpService(self):
        return self._HttpService


