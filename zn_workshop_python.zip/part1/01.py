# -*- coding: utf-8 -*-
from burp import IBurpExtender
from burp import IScannerCheck
from java.io import PrintWriter
from java.lang import RuntimeException
import code

class BurpExtender(IBurpExtender, IScannerCheck):
    
    #
    # implement IBurpExtender
    #
    
    def	registerExtenderCallbacks(self, callbacks):

        global burp_callbacks
        burp_callbacks = callbacks
        global burp_helpers
        burp_helpers = burp_callbacks.getHelpers()
        # set our extension name
        burp_callbacks.setExtensionName("ZN Extension 0.1")
        
        # obtain our output and error streams
        self.stdout = PrintWriter(callbacks.getStdout(), True)
        self.stderr = PrintWriter(callbacks.getStderr(), True)
        
        # write a message to our output stream
        self.stdout.println("Hello output")
        self.stdout.println("Plugin version 0.1")
        
        # write a message to our error stream
        self.stderr.println("Hello errors")
        
        # write a message to the Burp alerts tab
        burp_callbacks.issueAlert("Hello alerts")
        burp_callbacks.registerScannerCheck(self)
        
        # throw an exception that will appear in our error stream
        #raise RuntimeException("Hello exception")

    #create function for active scan
    def doActiveScan(self, baseRequestResponse, insertionPoint):
        name = insertionPoint.getInsertionPointName()
        value = insertionPoint.getBaseValue()
        self.println("Insertion point name {}, base value {}".format(name, value))

        payload = "ATTACK_HERE"
        payload_bytes = burp_helpers.stringToBytes(payload)
        attack = burp_callbacks.makeHttpRequest(baseRequestResponse.getHttpService(),
                                                 insertionPoint.buildRequest(payload_bytes))
        response = attack.getResponse()

        #if name == "cc":
        if False:
            loc=dict(locals())
            c = code.InteractiveConsole(locals=loc)
            c.interact("Interactive python interpreter")

    def doPassiveScan(self, baseRequestResponse):
        pass

    def println(self, message):
        self.stdout.println(message)
        