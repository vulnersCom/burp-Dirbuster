# -*- coding: utf-8 -*-
__author__ = 'videns'
import flask
from string import Template
app = flask.Flask(__name__)

basic_template = Template("""<html>
<head>
<title>Home of Test Web Site</title>
</head>
<body>
${form_data}
<br/>
${body}
</body>
</html>
""")

form_data = """<form method="POST">
<input type="text" name="id" value="0">
<input type="submit" value="Search"/>
</form>
"""

data_dict = {"1":"<b>Posters</b><br/>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy. Cras quis libero. Cras venenati",
             "2":"<b>Paintings</b><br/>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy. Cras quis libero. Cras venenati"}

@app.route("/", methods=['GET', 'POST'])
def reflectData():
    if flask.request.method == "GET":
        response_data = basic_template.safe_substitute({"form_data":form_data, "body":""})
        #print(response_data)
    else:
        id = flask.request.form.to_dict().get("id")
        if "win.ini" in id:
            body ="PHP Fatal error: Cannot call overloaded function for non-object in /home/xxxxxx/public_html/wp-includes/class-wp.php on line 529"
        else:
            body = data_dict.get(id, "Nothing found")
        response_data = basic_template.safe_substitute({"form_data":form_data, "body":body})
    return response_data

@app.route("/aa")
def test():
    myid = flask.request.args.get("myid")
    response = flask.Response("Some test response")
    response.headers["myid"] = myid
    return response

if __name__ == "__main__":
    app.run(host="127.0.0.1",port=int("8000"),debug=True)